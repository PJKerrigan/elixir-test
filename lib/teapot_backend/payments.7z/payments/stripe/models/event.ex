defmodule TeapotBackend.Payments.Stripe.Models.Event do
  alias __MODULE__
  alias TeapotBackend.Repo
  import Ecto.Changeset
  import Ecto.Query
  use Ecto.Schema

  @derive {Phoenix.Param, key: :id}
  @foreign_key_type :binary_id
  @primary_key {:id, :binary, autogenerate: false}
  @timestamps_opts [type: Ecto.DateTime, usec: true]

  schema "stripe_events" do
    field :account, :binary
    field :api_version, :binary
    field :data, :map
    field :idempotency_key, :binary
    field :livemode, :boolean
    field :object_id, :binary, default: nil
    field :pending_webhooks, :integer
    field :type, :binary
    timestamps(type: :utc_datetime_usec)
  end

  def changeset_insert(model, attrs) do
    model
    |> cast(attrs, [
      :account,
      :api_version,
      :data,
      :id,
      :idempotency_key,
      :livemode,
      :object_id,
      :pending_webhooks,
      :type
    ])
    |> validate_required([:api_version, :data, :id, :livemode, :pending_webhooks, :type])
    |> unique_constraint(:id, name: :stripe_events_pkey)
  end

  def exists?(id) do
    Repo.exists?(from x in Event, where: x.id == ^id)
  end

  def create(%{ id: id } = opts) do
    case exists?(id) do
      true -> {:error, :stripe_event_model_exists}
      false ->
        Event.changeset_insert(%Event{}, opts)
        |> Repo.insert()
    end
  end
end
